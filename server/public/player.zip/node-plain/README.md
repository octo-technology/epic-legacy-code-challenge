# Run

```
npm start
```

# Test

```
npm test
```

# Resources

* [Simplified HTTP request client](https://github.com/request/request)
* [Using Jasmine-Node to Test Your Node Server](http://randomjavascript.blogspot.fr/2012/12/using-jasmine-node-to-test-your-node.html)

module.exports = {
  port: 1338,
  host: "localhost"
}

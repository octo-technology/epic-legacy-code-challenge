module.exports = {
  port: 1337,
  host: "0.0.0.0"
}
